using System.IO;
using System.Text.RegularExpressions;
namespace Antivirus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private int viruses = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            label1.Text = folderBrowserDialog1.SelectedPath;
            viruses = 0;
            label2.Text = "Viruses: " + viruses.ToString();
            progressBar1.Value = 0;
            listBox1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            string[] search = Directory.GetFiles(folderBrowserDialog1.SelectedPath);
            progressBar1.Maximum = search.Length;
            progressBar1.Increment(1);
            foreach (string item in search)
            {
                try
                {
                    StreamReader stream = new StreamReader(item);
                    string read = stream.ReadToEnd();
                    string[] virus = new string[] { "trojan", "virus", "hacker","WannaCry",
    "Locky",
    "Zeus Trojan",
    "Mirai Botnet",
    "CryptoLocker",
    "Conficker",
    "Stuxnet",
    "CodeRed",
    "Nimda",
    "Sasser", };
                    foreach (string st in virus)
                    {
                        if (Regex.IsMatch(read, st))
                        {
                            MessageBox.Show("Virus Detected");
                            viruses++;
                            label2.Text = "Viruses" + viruses.ToString();
                            listBox1.Items.Add(item);

                        }
                       
                        progressBar1.Increment(1);
                    }
                }
                catch
                {
                    string read = item;
                    string[] virus = new string[] { "trojan", "virus", "hacker","WannaCry",
    "Locky",
    "Zeus Trojan",
    "Mirai Botnet",
    "CryptoLocker",
    "Conficker",
    "Stuxnet",
    "CodeRed",
    "Nimda",
    "Sasser", };
                    foreach (string st in virus)
                    {
                        if (Regex.IsMatch(read, st))
                        {
                            MessageBox.Show("Virus Detected");
                            viruses++;
                            label2.Text = "Viruses" + viruses.ToString();
                            listBox1.Items.Add(item);

                        }
                        progressBar1.Increment(1);
                    }


                }


            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            label1.Text = folderBrowserDialog1.SelectedPath;
            viruses = 0;
            label2.Text = "Viruses: " + viruses.ToString();
            progressBar1.Value = 0;
            listBox1.Items.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("No viruses detected.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete the selected viruses?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                foreach (string file in listBox1.Items)
                {
                    bool deletionSuccessful = false;
                    int retries = 3; // Number of retries
                    while (!deletionSuccessful && retries > 0)
                    {
                        try
                        {
                            File.Delete(file);
                           // listBox1.Items.Remove(file);
                            viruses--;
                            label2.Text = "Viruses: " + viruses.ToString();
                            deletionSuccessful = true; // Mark deletion as successful
                        }
                        catch (IOException)
                        {
                            // File is in use, wait for a short period and retry
                            System.Threading.Thread.Sleep(500); // Wait for 500 milliseconds
                            retries--; // Decrement the number of retries
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error deleting file: {file}. {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break; // Exit the loop if an error occurs other than IOException
                        }
                    }

                    if (!deletionSuccessful)
                    {
                        MessageBox.Show($"Error deleting file: {file}. The file is in use by another process.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                MessageBox.Show("Selected viruses deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Your existing code here
    
}
}
